1. git clone https://github.com/allssu/discord-nodejs-quiz.git
2. npm install
3. node index.js